// 定义内容
export default {
	card: {
		title1: '商品销售情况',
		title2: '环境监测',
		title3: '预警信息',
		title4: '动态信息',
		title5: '履约超时预警',
	},
	table: {
		th1: '时间',
		th2: '实验室名称',
		th3: '报警内容',
	},
};
