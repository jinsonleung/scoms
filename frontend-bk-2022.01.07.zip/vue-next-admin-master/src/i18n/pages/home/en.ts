// 定义内容
export default {
	card: {
		title1: 'Commodity sales',
		title2: 'environmental monitoring',
		title3: 'Early warning information',
		title4: 'dynamic information',
		title5: 'Performance overtime warning',
	},
	table: {
		th1: 'time',
		th2: 'Laboratory name',
		th3: 'Alarm content',
	},
};
