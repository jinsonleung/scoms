// 定义内容
export default {
	card: {
		title1: '商品銷售情况',
		title2: '環境監測',
		title3: '預警資訊',
		title4: '動態資訊',
		title5: '履約超時預警',
	},
	table: {
		th1: '時間',
		th2: '實驗室名稱',
		th3: '報警內容',
	},
};
